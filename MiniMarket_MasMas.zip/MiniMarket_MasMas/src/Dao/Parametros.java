
package Dao;

public interface Parametros {
    
    String driver = "com.mysql.cj.jdbc.Driver";
    String ruta = "jdbc:mysql://localhost:3306/bd_ventas3";
    String usuario = "root";
    String clave = "qwerty";
}
