package Modelo;
// libreria
import javax.swing.JTable;

public interface TablaRoles {
    public String[] Encabezado = {"Num", "Nombre"};
    public void MostrarEnTabla(JTable tabla);
}
